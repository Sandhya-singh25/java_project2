package in.sandhyait.props;

public class AppProps {

}
