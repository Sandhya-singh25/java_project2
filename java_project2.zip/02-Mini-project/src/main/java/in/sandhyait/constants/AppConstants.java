package in.sandhyait.constants;

public class AppConstants {

}
