package in.sandhyait.controller;

public class LoginForm {

}
