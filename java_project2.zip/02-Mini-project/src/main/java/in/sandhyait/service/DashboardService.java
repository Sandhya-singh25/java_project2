package in.sandhyait.service;

public interface DashboardService {
	
	public String getQuote();

}
