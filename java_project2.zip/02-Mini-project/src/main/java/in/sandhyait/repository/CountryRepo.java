package in.sandhyait.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sandhyait.entity.Country;

public interface CountryRepo extends JpaRepository<Country, Integer> {

}
